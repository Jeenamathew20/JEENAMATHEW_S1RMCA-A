<html>
    <head>
        <title>menu</title>
        <link rel="stylesheet" href="b2.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<h1><center>welocome to my garden<center></h1>
    <div class="menu-bar">
        <ul>
            <li class="active"><a href="#">HOME</a></li>
            <li><a href="signup.php">login</a></li>
            <li><a href="#">register</a></li>
            <li><a href="payment.php">payment</a></li>
            <li><a href="simple-shopping-cart/index1.php">Add cart</a></li>
            
            <li><a href="#">about as</a></li>
            <li><a href="#">contact</a></li>
            <li><a href="logout.php">LOGOUT</a></li>

</ul>
</div>


<?php 
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {

 ?>
<!DOCTYPE html>
<html>
<head>
	<title>HOME</title>
	<link rel="stylesheet" type="text/css" href="b2.css">
</head>
<body>
     <h1>Hello, <?php echo $_SESSION['name']; ?></h1>
     <a href="logout.php">Logout</a>
</body>
</html>

<?php 
}else{
     header("Location: index.php");
     exit();
}
 ?>
 </body>
</html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial;
  margin: 0;
}

* {
  box-sizing: border-box;
}

img {
  vertical-align: middle;
}

/* Position the image container (needed to position the left and right arrows) */
.container {
  position: relative;
}

/* Hide the images by default */
.mySlides {
  display: none;
}

/* Add a pointer when hovering over the thumbnail images */
.cursor {
  cursor: pointer;
}

/* Next & previous buttons */
.prev,
.next {
  cursor: pointer;
  position: absolute;
  top: 40%;
  width: auto;
  padding: 16px; 
  margin-top: -50px;
  color: white;
  font-weight: bold;
  font-size: 20px;
  border-radius: 0 3px 3px 0;
  user-select: none;
  -webkit-user-select: none;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover,
.next:hover {
  background-color: rgba(0, 0, 0, 0.8);
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* Container for image text */
.caption-container {
  text-align: center;
  background-color: #00FFFF;
  padding: 2px 16px;
  color: white;
}

.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Six columns side by side */
.column {
  float: left;
  width: 16.66%;
}

/* Add a transparency effect for thumnbail images */
.demo {
  opacity: 0.6;
}

.active,
.demo:hover {
  opacity: 1;
}
</style>
<body>

<h2 style="text-align:center">New</h2>

<div class="container">
  <div class="mySlides">
    <div class="numbertext">1 / 6</div>
    <img src="as1.jpg" style="width:50%",height="60%">
  </div>

  <div class="mySlides">
    <div class="numbertext">2 / 6</div>
    <img src="as2.jpg" style="width:50%",height="50%">
  </div>

  <div class="mySlides">
    <div class="numbertext">3 / 6</div>
    <img src="as3.jpg" style="width:50%",height="50%">
  </div>
    
  <div class="mySlides">
    <div class="numbertext">4 / 6</div>
    <img src="as4.jpg" style="width:50%",height="50%">
  </div>

  <div class="mySlides">
    <div class="numbertext">5 / 6</div>
    <img src="as5.jpg" style="width:50%",height="50%">
  </div>
    
  <div class="mySlides">
    <div class="numbertext">6 / 6</div>
    <img src="as6.jpg" style="width:50%",height="50%">
  </div>
    
  <a class="prev" onclick="plusSlides(-1)" >❮</a>
  <a class="next" onclick="plusSlides(1)">❯</a>
<br>
  <div class="caption-container">
    <p id="caption"></p>
  </div>
<h5>
  <div class="row" >
    <div class="column">
      <img class="demo cursor" src="as7.jpg" style="width:100%" onclick="currentSlide(1)" alt="">
    </div>
    <div class="column">
      <img class="demo cursor" src="as8.jpg" style="width:100%" onclick="currentSlide(2)" alt="">
    </div>
    <div class="column">
      <img class="demo cursor" src="as9.jpg" style="width:100%" onclick="currentSlide(3)" alt="">
    </div>
    <div class="column">
      <img class="demo cursor" src="as10.jpg" style="width:100%" onclick="currentSlide(4)" alt="">
    </div>
    <div class="column">
      <img class="demo cursor" src="as11.jpg" style="width:100%" onclick="currentSlide(5)" alt="">
    </div>    
    <div class="column">
      <img class="demo cursor" src="as12.jpg" style="width:100%" onclick="currentSlide(6)" alt="">
    </div>
  </div>
</div>
</h5>

<script>
var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("demo");
  var captionText = document.getElementById("caption");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
  captionText.innerHTML = dots[slideIndex-1].alt;
}
</script>
<br>
  <div class="caption-container">
    <p id="caption" ><b>Our gaurden</b></p>
  </div>

<p><h3>Gardening is the growing of plants such as flowers, shrubs and trees as a hobby or recreation.
 Some people also grow vegetables or fruit in their gardens. ... Grow tent helps plant to grow in a more spectacular and develop a friendly environment.
 Water gardening is growing plants in ornamental pools and ponds.
</h3></p>
<br>
  <div class="caption-container">
    <p id="caption" ><b><h4>We offers You the best customer services<h4></b></p>
  </div>
  </body>
</html>

