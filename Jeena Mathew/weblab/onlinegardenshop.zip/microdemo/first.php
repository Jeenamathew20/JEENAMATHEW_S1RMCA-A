<html>
    <head>
        <title>menu</title>
        <link rel="stylesheet" href="s1.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <div class="menu-bar">
        <ul>
            <li class="active"><a href="signup.php"><i class="fa fa-home"></i>HOME</a></li>
            <li><a href="#"><i class="fa fa-user"></i>login</a></li>
            <li><a href="#"><i class="fa fa-clone"></i>register</a></li>
            <li><a href="#"><i class="fa fa-users"></i>about as</a></li>
            <li><a href="#"><i class="fa fa-anglist"></i>contact</a></li>
</ul>
</div>
<center>
<h1>WELCOME TO MY GARDEN</h1>
</body>
</html>